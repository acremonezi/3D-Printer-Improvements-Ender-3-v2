                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3426272
Ender 3 Cable Chain by Jaylouisw is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a remix of johnnieWhiskey's original cable chain for the Creality Ender 3.
I have compiled it into a single STL file for easier printing.


PRINT CE3_cableChain_AllParts.stl ONLY!
USE OTHER PARTS AS SPARES/REPLACEMENTS.

the CE3_cableChain_AllParts.stl contains:

25x cableChain_link_v3.stl 
** refer to update at the bottom
25x cableChain_linkCover_v2.stl
1x cableChain_40MountTop_v2.stl
1x cableChain_XendCover.stl
1x cableChain_40MountSide_v2.stl
1x cableChain_bedCorner_v2.stl
1x cableChain_bedCornerCover_v2.stl
1x cableChain_plateMount_v2.stl

Please note:
The main STL is aligned for the best printing outcome, and it all fits on the bed of the Ender 3. with the Settings I have detailed, it takes 10hrs and 25mins to print.
You only need :
1x cableChain_bedCorner_v2.stl
and
1x cableChain_bedCornerCover_v2.stl

or
1x cableChain_plateMount_v2.stl
not all of them.


Should you need any extra length on the cable chains, just print extras of the cableChain_link_v3.stl and cableChain_linkCover_v2.stl


UPDATE-17/02/2019:
I have just realised that it only contains 24 links, so make sure to print one extra

# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: No
Resolution: 0.15mm
Infill: 20%
Filament_brand: creality
Filament_material: PLA

Notes: 
Temperature: 200C
Bed Temperature: 60C
Speed: 60mm/s
Skirt: Yes
Skirt Line Count: 2
Skirt Distance: 1mm